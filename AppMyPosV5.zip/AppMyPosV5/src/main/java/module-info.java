module mypos {
    // requires 表示此mypos模組依賴於其他外部引入的模組
    // 使用 requires 聲明的模組將在編譯和運行時被引入，使得本模組可以使用這些被引入模組的公開API
    requires javafx.controls;  // 或requires transitive javafx.controls; 引入 JavaFX 控制UI元件 (按鈕、表格等元件)
    requires javafx.base;      // 引入 JavaFX 基礎功能 (屬性綁定、集合、事件等)
    requires javafx.graphics;  // 引入 JavaFX 圖形功能 (場景、畫布、佈局等)

    //資料庫相關的依賴
    requires java.sql;         // 引入 JDBC API 用於資料庫連接與操作
    requires org.xerial.sqlitejdbc; // 引入 SQLite JDBC 驅動程式
    
    //相關的套件卷夾 - 只有需要被外部模組存取的套件才需要export
    exports models;     // 資料模型，JavaFX產品表格、訂單明細表格會用於顯示
    exports mypos;      // AppOrderEntry.java等幾個程式需要被JavaFX應用程式架構存取
    exports app;        // 主選單入口UI，必須開放，JavaFX能能使用

    // 以下模組不需要開放，這些屬於同一個專案下的套件目錄，不必exports即可叫用。
    // exports db;         // 資料庫連接相關
    // exports dao;        // 資料存取物件
    //exports test_order_db;  // 測試用
    
    // 模組系統說明:
    // 1. requires - 聲明模組依賴關係，使本模組能使用被依賴模組的公開API
    // 2. exports - 聲明哪些包可以被其他模組使用
    // 3. requires 與 exports 共同形成模組間的依賴與封裝關係
    //
    // requires 修飾符:
    // - requires static: 編譯時依賴，運行時可選
    // - requires transitive: 傳遞性依賴，使用此模組的其他模組也會自動依賴這些模組
    
    // 注意: 必須引入(requires)所有你需要使用的外部模組，否則編譯或運行時會報錯
}
