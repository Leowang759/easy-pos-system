package models;

public class Product {

    private String product_id;
    private String category;
    private String name;
    private int price;
    private String image_url;

    private String description;

    public Product(String id, String category, String name, int price, String image_url, String description) {
        this.product_id = id;
        this.category = category;
        this.name = name;
        this.price = price;
        this.image_url = image_url;
        this.description = description;
    }

    public Product() {
    }

    public String getProductId() {
        return product_id;
    }

    public void setProductId(String product_id) {
        this.product_id = product_id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getImageUrl() {
        return image_url;
    }

    public void setImageUrl(String image_url) {
        this.image_url = image_url;
    }

    @Override
    public String toString() {
        return "Product [id=" + product_id + ", name=" + name + ", price=" + price + "]";
    }

}
