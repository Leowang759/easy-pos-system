package app;

// ====== 匯入相關套件 ======
// JavaFX UI 元件與佈局
import dao.EmployeeDAO;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import models.Employee;
import mypos.AppDailyReport;
import mypos.AppOrderEntry;
import mypos.AppProductMaintenance;

// ====== 主程式類別 ======
public class MainMenuApp extends Application {

    // ====== 欄位宣告區（全域變數） ======
    private BorderPane root; // 主畫面容器
    private VBox menuBox; // 左側功能選單
    private StackPane contentPane; // 主內容顯示區
    private ToggleButton toggleMenuBtn; // 左上角 menu 摺疊按鈕

    // 登入狀態與功能按鈕陣列
    private boolean loggedIn = false; // 是否已登入
    private Button[] functionButtons; // 所有功能按鈕
    private Button loginLogoutBtn; // 登入/登出按鈕

    // 登入/登出圖示
    private Image loginImage;   // 需要設為全域變數（類別欄位），因為登入/登出圖示會在多個方法中使用
    private Image logoutImage;  // 例如：initLoginLogoutBtn() 和 updateLoginState() 都會用到

    // 資料存取物件與目前登入使用者
    private final EmployeeDAO employeeDAO = new EmployeeDAO();
    private Employee currentUser = null;

    // 顯示登入者姓名的標籤
    private final Label userInfoLabel = new Label("");

    // ====== JavaFX 應用程式進入點 ======
    @Override
    public void start(Stage primaryStage) {
        // 1. 初始化主容器與佈局
        root = new BorderPane();
        root.setPadding(new Insets(10));

        // 2. 初始化各個 UI 元件
        initMenuBox();         // 左側功能選單
        initContentPane();     // 主內容顯示區
        initToggleMenuBtn();   // 左上角 menu 摺疊按鈕
        initLoginLogoutBtn();  // 登入/登出按鈕
        initTitleBar();        // 標題列（含系統名稱與登入資訊）

        // 3. 預設顯示首頁
        setContent(createWelcomePane());

        // 4. 預設所有功能按鈕禁用（未登入時）
        updateLoginState();

        // 5. 設定 Scene 與顯示視窗
        Scene scene = new Scene(root, 1200, 600);
        scene.getStylesheets().add(getClass().getResource("/css/bootstrap3.css").toExternalForm());
        primaryStage.setTitle("簡易麵店 POS System");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // ====== UI 元件初始化方法 ======
    // 初始化左側功能選單
    private void initMenuBox() {
        menuBox = new VBox(15);
        menuBox.setPadding(new Insets(10));
        menuBox.setAlignment(Pos.TOP_CENTER);

        // 建立每個功能按鈕，並設定圖示
        Button orderBtn = createMenuButton("前台訂單輸入", "/images/order.png");
        Button productBtn = createMenuButton("產品維護管理", "/images/product.png");
        Button reportBtn = createMenuButton("銷售報表", "/images/bar_chart.png");
        /* Button userBtn = createMenuButton("使用者管理", "/images/user.png");
        Button analysisBtn = createMenuButton("數據分析", "/images/analysis.png");*/

        // 將所有功能按鈕放入陣列，方便統一管理啟用/禁用狀態
        functionButtons = new Button[]{orderBtn, productBtn, reportBtn};
        //functionButtons = new Button[] { orderBtn, productBtn, reportBtn, userBtn, analysisBtn };
        // 設定按鈕樣式
        orderBtn.getStyleClass().setAll("button", "info");
        productBtn.getStyleClass().setAll("button", "info");
        reportBtn.getStyleClass().setAll("button", "info");
        /*userBtn.getStyleClass().setAll("button", "info");
        analysisBtn.getStyleClass().setAll("button", "info");*/

        // 設定每個按鈕的點擊事件
        // 以下以 orderBtn 為例，逐行加上說明
        orderBtn.setOnAction( // 設定 orderBtn（前台訂單輸入按鈕）的事件處理器
                e
                -> // 當按鈕被點擊時，執行右側的 Lambda 表達式
                setContent( // 呼叫 setContent 方法，將主內容區切換為新的畫面
                        createOrderPane() // 建立並取得訂單輸入頁面的 Pane
                )
        );
        // 其他功能按鈕同理
        productBtn.setOnAction(e -> setContent(createProductPane()));
        reportBtn.setOnAction(e -> setContent(createReportPane()));
        /*        userBtn.setOnAction(e -> setContent(createUserPane()));
        analysisBtn.setOnAction(e -> setContent(createAnalysisPane()));*/

        // 將所有功能按鈕加入 menuBox
        menuBox.getChildren().addAll(orderBtn, productBtn, reportBtn);
        //menuBox.getChildren().addAll(orderBtn, productBtn, reportBtn, userBtn, analysisBtn);
        root.setLeft(menuBox);
    }

    // 初始化主內容顯示區
    private void initContentPane() {
        contentPane = new StackPane();
        contentPane.setPadding(new Insets(20));
        contentPane.setStyle("-fx-background-color: #f8f9fa; -fx-border-color: #ddd;");
        contentPane.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
        root.setCenter(contentPane);
    }

    // 初始化左上角 menu 摺疊按鈕
    private void initToggleMenuBtn() {
        toggleMenuBtn = new ToggleButton("≡");
        toggleMenuBtn.setStyle("-fx-font-size: 18px; -fx-background-radius: 5;");
        toggleMenuBtn.setFocusTraversable(false);
        toggleMenuBtn.setSelected(true);
        toggleMenuBtn.getStyleClass().addAll("toggle-button", "info"); // 使用 Bootstrap3 風格
        // 監聽 toggleMenuBtn 的選取狀態，切換 menuBox 顯示/隱藏
        // 監聽 toggleMenuBtn（≡ 按鈕）的選取狀態
        // 當 toggleMenuBtn 被點擊（選取/取消選取）時，會觸發此監聽器
        // isSelected 為 true 時，顯示左側 menuBox；為 false 時，隱藏 menuBox
        toggleMenuBtn.selectedProperty().addListener((obs, wasSelected, isSelected) -> {
            if (isSelected) {
                root.setLeft(menuBox); // 顯示左側功能選單
            } else {
                root.setLeft(null); // 隱藏左側功能選單
            }
        });
    }

    // 初始化登入/登出按鈕
    private void initLoginLogoutBtn() {
        loginImage = new Image(getClass().getResourceAsStream("/images/login.png"), 20, 20, true, true);
        logoutImage = new Image(getClass().getResourceAsStream("/images/logout.png"), 20, 20, true, true);

        loginLogoutBtn = new Button("登入", new ImageView(loginImage));
        loginLogoutBtn.setStyle("-fx-font-size: 14px;");
        loginLogoutBtn.getStyleClass().setAll("button", "warning");

        userInfoLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #337ab7; -fx-padding: 0 10 0 10;");

        // 設定登入/登出按鈕的事件處理
        // 可以直接呼叫 handleLoginLogout() 方法來統一處理登入與登出流程
        loginLogoutBtn.setOnAction(e -> handleLoginLogout());

        // 完整的匿名類別寫法（等價於上面 Lambda 寫法）
        /*
        loginLogoutBtn.setOnAction(new javafx.event.EventHandler<javafx.event.ActionEvent>() {
            @Override
            public void handle(javafx.event.ActionEvent e) {
                handleLoginLogout();
            }
        });
         */
        // 這裡 new EventHandler<ActionEvent>() 是實作介面，並覆寫 handle 方法
    }

    // 初始化標題列（包含系統名稱與登入資訊）
    private void initTitleBar() {
        Label titleLabel = new Label("簡易麵店 POS System");
        titleLabel.setStyle("-fx-font-size: 22px; -fx-font-weight: bold;");

        HBox titleBox = new HBox(10, toggleMenuBtn, titleLabel);
        titleBox.setAlignment(Pos.CENTER_LEFT);
        titleBox.setPadding(new Insets(5, 0, 5, 15));
        HBox rightBox = new HBox(userInfoLabel, loginLogoutBtn);
        rightBox.setAlignment(Pos.CENTER_RIGHT);
        rightBox.setSpacing(10);
        HBox titleBar = new HBox(titleBox, rightBox);
        titleBar.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(titleBox, Priority.ALWAYS);
        titleBar.setSpacing(20);

        root.setTop(titleBar);
    }

    // ====== 狀態更新與輔助方法 ======
    // 處理登入與登出邏輯的方法
    // 如果目前尚未登入，則顯示登入對話框，讓使用者輸入帳號密碼
    // 如果已經登入，則執行登出，並回到歡迎頁面
    private void handleLoginLogout() {
        if (!loggedIn) {
            // 顯示登入對話框
            GridPane grid = new GridPane();
            grid.setHgap(10);
            grid.setVgap(10);
            grid.setPadding(new Insets(20, 10, 10, 10));

            // 建立使用者名稱與密碼輸入欄位
            Label userLabel = new Label("使用者:");
            TextField userField = new TextField(); // 使用者名稱輸入框
            userField.setPromptText("Username");

            Label pwdLabel = new Label("密碼:");
            PasswordField pwdField = new PasswordField(); // 密碼輸入框
            pwdField.setPromptText("Password");

            // 將元件加入 GridPane
            grid.add(userLabel, 0, 0);
            grid.add(userField, 1, 0);
            grid.add(pwdLabel, 0, 1);
            grid.add(pwdField, 1, 1);

            // 建立自訂 Dialog 視窗
            Dialog<String[]> dialog = new Dialog<>();
            dialog.setTitle("登入");
            dialog.setHeaderText("請輸入使用者名稱與密碼");
            dialog.getDialogPane().setContent(grid); // 設定對話框內容為前面定義的 GridPane
            dialog.getDialogPane().getButtonTypes().clear();
            dialog.getDialogPane().getButtonTypes().addAll(
                    ButtonType.CANCEL,
                    ButtonType.OK
            );

            // 讓游標自動聚焦在使用者名稱欄位
            Platform.runLater(userField::requestFocus);

            // 設定 Dialog 結果轉換器，取得使用者輸入的帳號密碼
            dialog.setResultConverter(dialogButton -> {
                if (dialogButton == ButtonType.OK) {
                    return new String[]{userField.getText(), pwdField.getText()}; // 返回使用者輸入的帳號與密碼
                }
                return null;
            });

            // 顯示對話框並處理登入驗證
            dialog.showAndWait().ifPresent(result -> {
                String usernameValue = result[0];
                String passwordValue = result[1];
                // 呼叫 DAO 進行帳號密碼驗證
                Employee user = employeeDAO.authenticate(usernameValue, passwordValue);
                if (user != null) {
                    // 驗證成功，設定登入狀態與目前使用者
                    loggedIn = true;
                    currentUser = user;
                    updateLoginState();
                } else {
                    // 驗證失敗，顯示錯誤訊息
                    Alert alert = new Alert(AlertType.ERROR, "帳號或密碼錯誤！");
                    alert.showAndWait();
                }
            });
        } else {
            // 登出流程：清除登入狀態與目前使用者，並回到歡迎頁面
            loggedIn = false;
            currentUser = null;
            updateLoginState();
            setContent(createWelcomePane());
        }
    }

    // 根據登入狀態啟用/禁用功能按鈕與切換登入/登出按鈕文字與圖示
    private void updateLoginState() {
        for (Button btn : functionButtons) {
            btn.setDisable(!loggedIn);
        }
        if (loggedIn) {
            loginLogoutBtn.setText("登出");
            loginLogoutBtn.setGraphic(new ImageView(logoutImage));
            // 顯示登入者姓名
            userInfoLabel.setText(currentUser != null ? currentUser.getUsername() : "");
        } else {
            loginLogoutBtn.setText("登入");
            loginLogoutBtn.setGraphic(new ImageView(loginImage));
            userInfoLabel.setText("");
        }
    }

    // ====== 建立各功能頁面的方法 ======
    // 建立帶有圖示的功能按鈕
    private Button createMenuButton(String text, String iconPath) {
        Button btn = new Button(text);
        ImageView icon = new ImageView(new Image(getClass().getResourceAsStream(iconPath)));
        icon.setFitWidth(24);
        icon.setFitHeight(24);
        btn.setGraphic(icon);
        btn.setPrefWidth(140);
        btn.setContentDisplay(ContentDisplay.LEFT);
        btn.setStyle("-fx-font-size: 12px;");
        btn.setAlignment(Pos.CENTER_LEFT); // 讓內容靠左
        btn.setGraphicTextGap(5); // 圖示與文字間距
        return btn;
    }

    // 將傳入的 pane 設為主內容區的唯一內容
    private void setContent(Pane pane) {
        pane.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE); // 讓內容自動撐滿
        contentPane.getChildren().setAll(pane);
    }

    // ====== 各功能頁面建立方法 ======
    // 歡迎頁面
    private Pane createWelcomePane() {
        Label label = new Label("歡迎使用 簡易麵店 POS System");
        label.setStyle("-fx-font-size: 18px;");
        VBox box = new VBox(label);
        box.setAlignment(Pos.CENTER);
        return box;
    }

    // 訂單輸入頁面
    private Pane createOrderPane() {
        System.out.println("建立訂單輸入頁面");
        //return new VBox();
        AppOrderEntry entryApp = new AppOrderEntry();
        // toggleMenuBtn.setSelected(false);
        // entryApp.start(new Stage());
        return entryApp.getRootPane();
    }

    // 產品維護管理頁面
    private Pane createProductPane() {
        System.out.println("建立產品維護管理頁面");
        //return new VBox();
        AppProductMaintenance maintenanceApp = new AppProductMaintenance();
        // toggleMenuBtn.setSelected(false);
        // maintenanceApp.start(new Stage());
        return maintenanceApp.getRootPane();
    }

    // 銷售報表頁面
    private Pane createReportPane() {
        System.out.println("建立銷售報表頁面");
        //return new VBox();
        AppDailyReport reportApp = new AppDailyReport();
        return reportApp.getRootPane();
    }

    // 使用者管理頁面
    /*private Pane createUserPane() {
        Label label = new Label("這是使用者管理頁面");
        VBox box = new VBox(label);
        box.setAlignment(Pos.CENTER);
        return box;
    }

    // 數據分析頁面
    private Pane createAnalysisPane() {
        Label label = new Label("這是數據分析頁面");
        VBox box = new VBox(label);
        box.setAlignment(Pos.CENTER);
        return box;
    }*/
    // ====== 主程式進入點 ======
    public static void main(String[] args) {
        launch(args);
    }

}
