package mypos;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import db.ProductDbManagerSimple;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import models.Product; // 新的資料服務

public class ProductMenuPane extends VBox {

    ProductDbManagerSimple productDbManager = new ProductDbManagerSimple();
    // 使用 productDbManagerSimple 替代 ReadCategoryProductFromFile
    private final String[] categories = productDbManager.getCategories();
    private final Map<String, TilePane> menus = new HashMap<>();
    private VBox menuContainerPane = new VBox();
    // 直接依賴於OrderPane實例，而非使用介面
    private OrderPane orderPane; // 直接依賴OrderPane實例

    // 建構子 - 直接接收OrderPane物件作為參數
    public ProductMenuPane(OrderPane orderPane) {
        this.orderPane = orderPane;
        setSpacing(10);
        
        // 初始化所有類別菜單
        for (String category : categories) {
            menus.put(category, getProductCategoryMenu(category));
        }
        
        // 添加類別選擇按鈕
        getChildren().add(getMenuSelectionContainer());
        
        // 添加菜單容器並設定預設類別 (如果類別不為空)
        if (categories.length > 0) {
            menuContainerPane.getChildren().add(menus.get(categories[0]));
        }
        getChildren().add(menuContainerPane);
    }
    
    // Get product category menu tile pane
    private TilePane getProductCategoryMenu(String category) {
        // 使用 productDbManagerSimple 獲取產品
        TreeMap<String, Product> product_dict = productDbManager.getProducts();
        // productDbManager.getProductsByCategory(  category );
        // Create tile pane
        TilePane category_menu = new TilePane();
        category_menu.setVgap(10);
        category_menu.setHgap(10);
        category_menu.setPrefColumns(4);

        // Add products to menu
        for (String item_id : product_dict.keySet()) {
            if (product_dict.get(item_id).getCategory().equals(category)) {
                Button btn = new Button();
                btn.setPrefSize(120, 120);
                
                System.out.println("產品ID: " + item_id + ", 名稱: " + product_dict.get(item_id).getName() + ", 價格: " + product_dict.get(item_id).getPrice() + ", 類別: " + product_dict.get(item_id).getCategory());
                // Set product image
                // Set product image with error handling
                ImageView imgview;
                try {
                    Image img = new Image(getClass().getResourceAsStream("/imgs/" + product_dict.get(item_id).getImageUrl()));
                    // Check if image was successfully loaded
                    if (img.isError() || img.getWidth() == 0) {
                        throw new Exception("Image not found or invalid");
                    }
                    imgview = new ImageView(img);
                    imgview.setFitHeight(80);
                    imgview.setPreserveRatio(true);
                    btn.setGraphic(imgview);
                } catch (Exception e) {
                    // Create a styled text placeholder that exactly matches the image size
                    VBox placeholderBox = new VBox();
                    placeholderBox.setAlignment(Pos.CENTER);
                    placeholderBox.setPrefHeight(80); // Match exact image height
                    placeholderBox.setPrefWidth(80); // Keep square ratio like typical product images
                    placeholderBox.setMinHeight(80);
                    placeholderBox.setMaxHeight(80);
                    placeholderBox.setStyle("-fx-border-color: #cccccc; -fx-background-color: #f8f8e8; -fx-border-radius: 5;");
                    
                    // Use formatted text for better display
                    javafx.scene.text.Text productText = new javafx.scene.text.Text(product_dict.get(item_id).getName());
                    productText.setWrappingWidth(70); // Slightly less than container width
                    productText.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
                    
                    placeholderBox.getChildren().add(productText);
                    btn.setGraphic(placeholderBox);
                    System.out.println("Could not load image for product: " + item_id + ", using text instead.");
                }
                
                //Image img = new Image(getClass().getResourceAsStream("/imgs/" + product_dict.get(item_id).getImageUrl()));
                //ImageView imgview = new ImageView(img);
                //imgview.setFitHeight(80);
                //imgview.setPreserveRatio(true);
                //btn.setGraphic(imgview);
                
                // Add to menu
                category_menu.getChildren().add(btn);

                // Set button action to add product to cart
                // 注意：這裡直接調用OrderPane的addToCart方法
                final String finalItemId = item_id;
                // 產品菜單按鈕點擊事件處理
                btn.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        // 直接呼叫OrderPane的addToCart方法，顯示高耦合设计
                        orderPane.addToCart(finalItemId);
                        System.out.println("已加入購物車: " + product_dict.get(finalItemId).getName());
                    }
                });
            }
        }
        return category_menu;
    }

    // Get menu selection container
    private TilePane getMenuSelectionContainer() {
        // Create container for category buttons
        TilePane containerCategoryMenuBtn = new TilePane();
        containerCategoryMenuBtn.setAlignment(Pos.CENTER_LEFT);
        containerCategoryMenuBtn.setPadding(new Insets(6));
        containerCategoryMenuBtn.setVgap(10);
        containerCategoryMenuBtn.setHgap(10);

        // Create category buttons
        for (String category : categories) {
            Button btn = new Button(category);
            btn.getStyleClass().setAll("button", "success");
            btn.setOnAction(event -> {
                menuContainerPane.getChildren().clear();
                menuContainerPane.getChildren().add(menus.get(category));
                System.out.println("Selected category: " + category);
            });
            containerCategoryMenuBtn.getChildren().add(btn);
        }

        return containerCategoryMenuBtn;
    }

    // 當應用關閉時應調用此方法
    // public void cleanup() {
    //     ProductDataService.closeConnection();
    // }
}
