package mypos;

import java.util.HashSet;
import java.util.Set;

import dao.ProductDAO;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.Pagination;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.converter.IntegerStringConverter;
import models.Product;

public class AppProductMaintenancePaging extends Application {

    //***********產生資料DAO來使用
    private final ProductDAO productDao = new ProductDAO();
    //ObservableList    order_list有新增或刪除都會處動table的更新，也就是發生任何改變時都被通知
    private final ObservableList<Product> product_list = FXCollections.observableList(productDao.getAllProducts());
    //private final ObservableList<Product> product_list = getProductList();
    private final Label statusLabel = new Label();

    // 分頁相關變數
    private static final int ROWS_PER_PAGE = 4;
    private TableView<Product> table;
    // Declare pagination as a class field
    private Pagination pagination;

    // Add a set to keep track of unsaved products
    private final Set<String> unsavedProducts = new HashSet<>();

    @Override
    public void start(Stage primaryStage) {
        VBox root = getRootPane();
        Scene scene = new Scene(root, 1000, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("高科資管POS系統");
        primaryStage.show();
    }

    public VBox getRootPane() {
        table = initializeProductTable();

        // 計算總頁數
        int pageCount = (int) Math.ceil((double) product_list.size() / ROWS_PER_PAGE);

        // 創建分頁控制器
        pagination = new Pagination(pageCount, 0);
        pagination.setPageFactory(this::createPage);

        VBox vbox = new VBox(pagination, statusLabel);
        //vbox.getStylesheets().add("/css/bootstrap3.css");
        vbox.getStylesheets().add(getClass().getResource("/css/bootstrap3.css").toExternalForm());

        // 添加CSS樣式
        table.getStyleClass().add("table");

        vbox.setSpacing(10);
        vbox.setAlignment(Pos.CENTER);

        return vbox;
    }

    // 創建分頁的方法
    private VBox createPage(int pageIndex) {
        int fromIndex = pageIndex * ROWS_PER_PAGE;
        int toIndex = Math.min(fromIndex + ROWS_PER_PAGE, product_list.size());

        // 根據當前頁碼更新表格中顯示的資料
        table.setItems(FXCollections.observableArrayList(
                product_list.subList(fromIndex, toIndex)));

        VBox box = new VBox();
        box.setSpacing(10);
        box.getChildren().add(table);
        return box;
    }

    public static void main(String[] args) {
        launch(args);
    }

    private TableColumn<Product, String> createColumn(String title, String propertyName) {
        TableColumn<Product, String> column = new TableColumn<>(title);
        column.setCellValueFactory(new PropertyValueFactory<>(propertyName));
        column.setCellFactory(TextFieldTableCell.forTableColumn());
        return column;
    }

    private TableColumn<Product, Integer> createColumn(String title, String propertyName, IntegerStringConverter converter) {
        TableColumn<Product, Integer> column = new TableColumn<>(title);
        column.setCellValueFactory(new PropertyValueFactory<>(propertyName));
        column.setCellFactory(TextFieldTableCell.forTableColumn(converter));
        return column;
    }

    /*
    <T> 是一個型別參數，它表示一個未知的類型。
    在方法或類的定義中，你可以使用 <T> 來表示一個泛型型別，並在實際使用時指定具體的類型。
    例如，<T> 可以是 String、Integer、Product 或其他任何類型。
     */
    private <T> void setEditCommitHandler(TableColumn<Product, T> column, String propertyName) {
        column.setOnEditCommit(event -> {
            Product product = event.getRowValue();
            switch (propertyName) {
                case "productId":
                    product.setProductId(event.getNewValue().toString());
                    break;
                case "category":
                    product.setCategory(event.getNewValue().toString());
                    break;
                case "name":
                    product.setName(event.getNewValue().toString());
                    break;
                case "price":
                    product.setPrice((Integer) event.getNewValue());
                    break;
                case "imageUrl":
                    product.setImageUrl(event.getNewValue().toString());
                    break;
                case "description":
                    product.setDescription(event.getNewValue().toString());
                    break;
            }
            System.out.println(propertyName + " updated: " + product);
        });
    }

    private void refreshPagination(Pagination pagination) {
        // Recalculate the page count
        int pageCount = (int) Math.ceil((double) product_list.size() / ROWS_PER_PAGE);

        // Update pagination
        pagination.setPageCount(pageCount);

        // Get current page index
        int currentPage = pagination.getCurrentPageIndex();
        // Ensure we don't exceed page count
        if (currentPage >= pageCount && pageCount > 0) {
            pagination.setCurrentPageIndex(pageCount - 1);
        }

        // 關鍵修正：重新設定當前頁的內容
        int fromIndex = pagination.getCurrentPageIndex() * ROWS_PER_PAGE;
        int toIndex = Math.min(fromIndex + ROWS_PER_PAGE, product_list.size());

        // 確保索引合法
        if (fromIndex < product_list.size()) {
            table.setItems(FXCollections.observableArrayList(
                    product_list.subList(fromIndex, toIndex)));
        } else if (product_list.isEmpty()) {
            // 如果清單空了，設置空表格
            table.setItems(FXCollections.observableArrayList());
        }
    }

    // 這個方法是用來初始化表格的，並且設定每一個欄位的屬性
    private TableView<Product> initializeProductTable() {

        product_list.forEach(System.out::println);
        TableView<Product> table = new TableView<>();
        table.setEditable(true);
        // 表格最後一欄是空白，不要顯示!
        table.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);

        // 定義表格欄位
        TableColumn<Product, String> idColumn = createColumn("Product ID", "productId"); // Product類別裡的getProductId()方法
        //TableColumn<Product, String> idColumn = createColumn("Product ID", "product_id"); // 這裡的product_id是Product類別裡的屬性名稱
        TableColumn<Product, String> categoryColumn = createColumn("Category", "category");
        TableColumn<Product, String> nameColumn = createColumn("Name", "name");
        TableColumn<Product, Integer> priceColumn = createColumn("Price", "price", new IntegerStringConverter());
        TableColumn<Product, String> image_urlColumn = createColumn("image_url", "imageUrl");//不要用image_url
        TableColumn<Product, String> descriptionColumn = createColumn("Description", "description");
        TableColumn<Product, Void> actionColumn = new TableColumn<>("Action");

        //descriptionColumn.setPrefWidth(500);
        actionColumn.setPrefWidth(350);

        // 設定欄位允許編輯後的事件處理
        setEditCommitHandler(idColumn, "productId");
        setEditCommitHandler(categoryColumn, "category");
        setEditCommitHandler(nameColumn, "name");
        setEditCommitHandler(priceColumn, "price");
        setEditCommitHandler(image_urlColumn, "imageUrl");
        setEditCommitHandler(descriptionColumn, "description");

        // 設定Action欄位的按鈕 小括弧裡面有定義一個lambda函數，lambda函數有一個內部匿名類別
        actionColumn.setCellFactory(param -> new TableCell<>() {

            //
            private final Button btnDelete = new Button("Delete");
            private final Button btnUpdate = new Button("Update");
            private final Button btnDuplicate = new Button("Duplicate");
            private final Button btnSave = new Button("Save");

            // 這裡一定要有大括弧{} 內部匿名類別(不可有建構子)的 初始化區塊 和 建構子的目的一樣，做初始化用途
            {
                //刪除按鈕
                btnDelete.setOnAction(event -> {
                    Product product = getTableRow().getItem();
                    if (product != null) {
                        // Create confirmation dialog
                        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                        alert.setTitle("確認刪除");
                        alert.setHeaderText("您即將刪除產品: " + product.getName());
                        alert.setContentText("確定要刪除這個產品嗎?");
                        
                        // Show dialog and wait for response
                        alert.showAndWait().ifPresent(response -> {
                            if (response == ButtonType.OK) {
                                // User confirmed, proceed with deletion
                                // 從資料庫刪除這一筆
                                boolean deleteSuccess = productDao.delete(product.getProductId());
                                if (deleteSuccess) {
                                    product_list.remove(product);
                                    statusLabel.setText("Deleted: " + product.getName());
                                    System.out.println("Deleted: " + product.getName());
                                } else {
                                    statusLabel.setText("Delete failed: " + product.getName());
                                    System.out.println("Delete failed: " + product.getName());
                                }
                                // Refresh pagination after deleting
                                //refreshPagination(pagination);
                            }
                        });
                    }
                });

                btnDelete.getStyleClass().setAll("button", "danger");
                // 更新按鈕
                btnUpdate.setOnAction(event -> {
                    Product product = getTableView().getItems().get(getIndex());
                    boolean updateSuccess = productDao.update(product);
                    if (updateSuccess) {
                        product_list.set(getIndex(), product); // 更新列表中的項目
                        statusLabel.setText("Updated: " + product.getName());
                        System.out.println("Updated: " + product.getName());
                    } else {
                        statusLabel.setText("Updated failed: " + product.getName());
                        System.out.println("Update failed for: " + product.getName());
                    }
                });
                btnUpdate.getStyleClass().setAll("button", "primary");

                //複製按鈕
                btnDuplicate.setOnAction(event -> {
                    Product product = getTableView().getItems().get(getIndex());
                    // Generate a new unique ID for the duplicated product (append timestamp)
                    String newProductId = product.getProductId() + "_copy_" + System.currentTimeMillis();
                    
                    // Create a new product with the generated ID
                    Product duplicatedProduct = new Product(
                        newProductId, 
                        product.getCategory(), 
                        product.getName() + " (Copy)", 
                        product.getPrice(), 
                        product.getImageUrl(), 
                        product.getDescription()
                    );
                    
                    // Add to the list and mark as unsaved
                    product_list.add(duplicatedProduct);
                    unsavedProducts.add(duplicatedProduct.getProductId());
                    
                    statusLabel.setText("Duplicated: " + product.getName() + " (Not saved to database)");
                    System.out.println("Duplicated: " + product.getName() + " (Not saved to database)");
                });
                btnDuplicate.getStyleClass().setAll("button", "warning");

                //儲存按鈕
                btnSave.setOnAction(event -> {
                    Product product = getTableView().getItems().get(getIndex());
                    
                    boolean saved = productDao.add(product);
                    if (saved) {
                        // If saved successfully, remove from unsavedProducts set
                        unsavedProducts.remove(product.getProductId());
                        statusLabel.setText("Saved: " + product.getName());
                        System.out.println("Saved: " + product.getName());
                        
                        // Force refresh to update row styling
                        table.refresh();
                    } else {
                        statusLabel.setText("Failed to save: " + product.getName());
                        System.out.println("Failed to save: " + product.getName());
                    }
                });
                btnSave.getStyleClass().setAll("button", "success");

            }

            // Add similar event handlers for other buttons (Update, Duplicate, Save)
            HBox pane = new HBox(btnUpdate, btnDuplicate, btnSave, btnDelete);

            {
                pane.setAlignment(Pos.CENTER);
                pane.setSpacing(10);
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                // Update the graphic when the item or empty status changes
                if (!empty) {
                    setGraphic(pane);
                } else {
                    setGraphic(null);
                }
            }
        });

        // Add a listener to the product_list to refresh pagination when the list changes
        product_list.addListener((javafx.collections.ListChangeListener.Change<? extends Product> change) -> {
            refreshPagination(pagination);
        });
        
        // Add columns to the table
        table.getColumns().addAll(idColumn, categoryColumn, nameColumn, priceColumn, image_urlColumn, descriptionColumn, actionColumn);

        // Add row factory to set different style for unsaved rows
        table.setRowFactory(tv -> {
            TableRow<Product> row = new TableRow<Product>() {
                @Override
                protected void updateItem(Product product, boolean empty) {
                    super.updateItem(product, empty);
                    
                    if (product == null || empty) {
                        setStyle("");
                    } else if (unsavedProducts.contains(product.getProductId())) {
                        // Set style for unsaved products
                        setStyle("-fx-background-color: #fff3cd;"); // Light yellow background
                    } else {
                        setStyle("");
                    }
                }
            };
            return row;
        });

        return table;
    }

}
