package mypos;

import dao.ProductDAO;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.converter.IntegerStringConverter;
import models.Product;

//--------------------
// 1. 主程式類別宣告
//--------------------
public class AppProductMaintenanceV1 extends Application {

    //--------------------
    // 2. 欄位宣告：資料存取、資料清單、狀態顯示
    //--------------------
    private final ProductDAO productDao = new ProductDAO();
    private final ObservableList<Product> product_list = FXCollections.observableList(productDao.getAllProducts());
    private final Label statusLabel = new Label("狀態顯示區");

    //--------------------
    // 3. JavaFX應用程式進入點
    //--------------------
    @Override
    public void start(Stage primaryStage) {
        VBox root = getRootPane();
        Scene scene = new Scene(root, 1100, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("高科資管POS系統");
        primaryStage.show();
    }

    //--------------------
    // 4. 建立主畫面元件
    //--------------------
    public VBox getRootPane() {


        // 新增查詢區塊元件
        HBox searchPane = new HBox();
        searchPane.setSpacing(10);
        searchPane.setAlignment(Pos.CENTER_LEFT);

        // 查詢產品ID
        Label lblId = new Label("ID:");
        TextField tfId = new TextField();
        Button btnSearchId = new Button("查詢ID");
        btnSearchId.getStyleClass().setAll("button", "primary");
        btnSearchId.setOnAction(e -> {
            statusLabel.setText("查詢產品ID: " + tfId.getText());
        });

        // 查詢產品類別
        Label lblCategory = new Label("類別:");
        TextField tfCategory = new TextField();
        Button btnSearchCategory = new Button("查詢類別");
        btnSearchCategory.setOnAction(e -> {
            statusLabel.setText("查詢產品類別: " + tfCategory.getText());
        });

        // 查詢全部產品
        Button btnAll = new Button("全部產品");
        btnAll.setOnAction(e -> {
            statusLabel.setText("顯示全部產品");
        });

        // 搜尋產品名稱
        Label lblName = new Label("名稱:");
        TextField tfName = new TextField();
        Button btnSearchName = new Button("搜尋名稱");
        btnSearchName.setOnAction(e -> {
            statusLabel.setText("搜尋產品名稱: " + tfName.getText());
        });

        searchPane.getChildren().addAll(
            lblId, tfId, btnSearchId,
            lblCategory, tfCategory, btnSearchCategory,
            lblName, tfName, btnSearchName,
            btnAll
        );

        // 產品表格
        // 初始化TableView，並設定欄位、按鈕等
        TableView<Product> table = initializeProductTable();

        VBox vbox = new VBox(searchPane, table, statusLabel);

        //vbox.getStylesheets().add("/css/bootstrap3.css"); 不能這樣寫!
        vbox.getStylesheets().add(getClass().getResource("/css/bootstrap3.css").toExternalForm());

        // 添加CSS樣式
        table.getStyleClass().add("table");

        vbox.setSpacing(10);
        vbox.setAlignment(Pos.CENTER);
        // 設定上下左右各20像素的padding
        vbox.setPadding(new Insets(20, 20, 20, 20));

        return vbox;
    }

    //--------------------
    // 5. 主程式進入點
    //--------------------
    public static void main(String[] args) {
        launch(args);
    }

    //--------------------
    // 6. 建立TableView欄位（字串型別）
    //--------------------
    private TableColumn<Product, String> createColumn(String title, String propertyName) {
        TableColumn<Product, String> column = new TableColumn<>(title);
        column.setCellValueFactory(new PropertyValueFactory<>(propertyName));
        column.setCellFactory(TextFieldTableCell.forTableColumn());
        return column;
    }

    //--------------------
    // 7. 建立TableView欄位（整數型別）
    //--------------------
    private TableColumn<Product, Integer> createColumn(String title, String propertyName, IntegerStringConverter converter) {
        TableColumn<Product, Integer> column = new TableColumn<>(title);
        column.setCellValueFactory(new PropertyValueFactory<>(propertyName));
        column.setCellFactory(TextFieldTableCell.forTableColumn(converter));
        return column;
    }

    //--------------------
    // 8. 設定欄位編輯完成的事件處理
    //--------------------
    /*
private <T> void setEditCommitHandler 方法說明：
- private：只有這個類別內部可以使用
- <T>：泛型型別參數，代表任何型別（String、Integer等）
- void：方法沒有回傳值
- setEditCommitHandler：方法名稱，用來設定欄位編輯完成後的處理
- TableColumn<Product, T> column：要設定的表格欄位，T代表欄位的資料型別
- String propertyName：Product物件中對應的屬性名稱

這個方法的用途是統一處理表格欄位編輯完成後要做的事情，
避免每個欄位都要重複寫相同的程式碼。

若不使用此方法，每個欄位都要分別設定，例如：
idColumn.setOnEditCommit(event -> {
    Product product = event.getRowValue();
    product.setProductId(event.getNewValue().toString());
    System.out.println("productId updated: " + product);
});

nameColumn.setOnEditCommit(event -> {
    Product product = event.getRowValue();
    product.setName(event.getNewValue().toString());
    System.out.println("name updated: " + product);
});
// 每個欄位都要重複寫類似的程式碼...
*/
private <T> void setEditCommitHandler(TableColumn<Product, T> column, String propertyName) {
        column.setOnEditCommit(event -> {
            Product product = event.getRowValue();
            switch (propertyName) {
                // 如果propertyName是"productId"，將新的值轉換為字串並設置到product的productId屬性中
                case "productId":
                    product.setProductId(event.getNewValue().toString());
                    break;
                // 如果propertyName是"category"，將新的值轉換為字串並設置到product的category屬性中
                case "category":
                    product.setCategory(event.getNewValue().toString());
                    break;
                case "name":
                    product.setName(event.getNewValue().toString());
                    break;
                case "price":
                    product.setPrice((Integer) event.getNewValue());
                    break;
                case "imageUrl":
                    product.setImageUrl(event.getNewValue().toString());
                    break;
                case "description":
                    product.setDescription(event.getNewValue().toString());
                    break;
            }
            System.out.println(propertyName + " updated: " + product);
        });
    }

    //--------------------
    // 9. 初始化TableView與所有欄位、按鈕
    //--------------------
    private TableView<Product> initializeProductTable() {
        TableView<Product> table = new TableView<>();
        table.setEditable(true);
        // 表格最後一欄是空白，不要顯示!
        // table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY); //自動均分欄位大小
        table.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);

        // 定義表格欄位
        TableColumn<Product, String> idColumn = createColumn("Product ID", "productId");
        TableColumn<Product, String> categoryColumn = createColumn("Category", "category");
        TableColumn<Product, String> nameColumn = createColumn("Name", "name");
        TableColumn<Product, Integer> priceColumn = createColumn("Price", "price", new IntegerStringConverter());
        TableColumn<Product, String> imageUrlColumn = createColumn("image_url", "imageUrl");
        TableColumn<Product, String> descriptionColumn = createColumn("Description", "description");
        // 設定欄位允許編輯後的事件處理
        setEditCommitHandler(idColumn, "productId");
        setEditCommitHandler(categoryColumn, "category");
        setEditCommitHandler(nameColumn, "name");
        setEditCommitHandler(priceColumn, "price");
        setEditCommitHandler(imageUrlColumn, "imageUrl");
        setEditCommitHandler(descriptionColumn, "description");

        //--------------------------------------------------------------
        // actionColumn 這個欄位特別需要特別訂製，因為它包含按鈕
        // Void 是 java.lang 套件裡的類別，代表「沒有型別」或「無值」
        TableColumn<Product, Void> actionColumn = new TableColumn<>("Action");
        // Void 是 java.lang 套件裡的類別，代表「沒有型別」或「無值」
        // java.lang.* 會自動匯入，所以不用手動 import Void
        // 在 TableColumn<Product, Void> 中，Void 表示這個欄位不對應任何資料屬性，只用來放元件

        //descriptionColumn.setPrefWidth(500);
        actionColumn.setPrefWidth(350);


        //--------------------
        // 10. Action欄位：包含Delete、Update、Duplicate、Save按鈕
        //--------------------
        // setCellFactory 用來自訂 TableColumn 的每個 cell 要如何顯示
        // param 是 TableColumn 物件本身，但通常不會用到，所以命名為 param
        // lambda 表達式 param -> 表示接收一個參數，回傳一個 TableCell 物件
        // -> 是 lambda 表達式的箭頭符號，左邊是參數，右邊是要執行的程式碼或回傳值
        // param -> new TableCell<>() 等同於傳統的匿名類別寫法，但更簡潔
        // new TableCell<>() {} 建立一個匿名的 TableCell 子類別，可以覆寫其方法來自訂顯示內容
        actionColumn.setCellFactory(param -> new TableCell<>() {

            private final Button btnDelete = new Button("Delete");
            private final Button btnUpdate = new Button("Update");
            private final Button btnDuplicate = new Button("Duplicate");
            private final Button btnSave = new Button("Save");
            // 這裡一定要有大括弧{} 內部匿名類別(不可有建構子)的 初始化區塊 和 建構子的目的一樣，做初始化用途
            {
                btnDelete.getStyleClass().setAll("button", "danger");
                btnDelete.setStyle("-fx-font-size: 12px; -fx-padding: 2 8 2 8;"); // 臨時縮小按鈕
                btnUpdate.getStyleClass().setAll("button", "primary");
                btnUpdate.setStyle("-fx-font-size: 12px; -fx-padding: 2 8 2 8;"); // 臨時縮小按鈕
                btnDuplicate.getStyleClass().setAll("button", "warning");
                btnDuplicate.setStyle("-fx-font-size: 12px; -fx-padding: 2 8 2 8;"); // 臨時縮小按鈕
                btnSave.getStyleClass().setAll("button", "success");
                btnSave.setStyle("-fx-font-size: 12px; -fx-padding: 2 8 2 8;"); // 臨時縮小按鈕


                //刪除按鈕
                btnDelete.setOnAction(event -> {
                    Product product = getTableRow().getItem();
                    if (product != null) {
                        // Create confirmation dialog
                        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                        alert.setTitle("確認刪除");
                        alert.setHeaderText("您即將刪除產品: " + product.getName());
                        alert.setContentText("確定要刪除這個產品嗎?");
                        
                        // Show dialog and wait for response
                        alert.showAndWait().ifPresent(response -> {
                            if (response == ButtonType.OK) {
                                // User confirmed, proceed with deletion
                                // 從資料庫刪除這一筆
                                boolean deleteSuccess = productDao.delete(product.getProductId());
                                if (deleteSuccess) {
                                    product_list.remove(product);
                                    statusLabel.setText("Deleted: " + product.getName());
                                    System.out.println("Deleted: " + product.getName());
                                } else {
                                    statusLabel.setText("Delete failed: " + product.getName());
                                    System.out.println("Delete failed: " + product.getName());
                                }
                                // Refresh pagination after deleting
                                //refreshPagination(pagination);
                            }
                        });
                    }
                });

                // 更新按鈕
                btnUpdate.setOnAction(event -> {
                    Product product = getTableView().getItems().get(getIndex());
                    boolean updateSuccess = productDao.update(product);
                    if (updateSuccess) {
                        product_list.set(getIndex(), product); // 更新列表中的項目
                        statusLabel.setText("Updated: " + product.getName());
                        System.out.println("Updated: " + product.getName());
                    } else {
                        statusLabel.setText("Updated failed: " + product.getName());
                        System.out.println("Update failed for: " + product.getName());
                    }
                });

                // 複製按鈕
                btnDuplicate.setOnAction(event -> {
                    Product product = getTableView().getItems().get(getIndex());


                    // Generate a new unique ID for the duplicated product (append timestamp)
                    String newProductId = product.getProductId() + "_copy_" + System.currentTimeMillis();
                    
                    // Create a new product with the generated ID
                    Product duplicatedProduct = new Product(
                        newProductId, 
                        product.getCategory(), 
                        product.getName() + " (Copy)", 
                        product.getPrice(), 
                        product.getImageUrl(), 
                        product.getDescription()
                    );
                    
                    // Add to the list and mark as unsaved
                    product_list.add(duplicatedProduct);

                    statusLabel.setText("Duplicated: " + product.getName()+ " (尚未存檔)");
                    System.out.println("Duplicated: " + product.getName()+ " (尚未存檔)");
                });

                // 儲存按鈕
                btnSave.setOnAction(event -> {
                    Product product = getTableView().getItems().get(getIndex());
                    productDao.add(product);
                    statusLabel.setText("Save: " + product.getName());
                    System.out.println("Save: " + product.getName());
                });
            } //按鈕事件定義

            // 按鈕排版
            HBox pane = new HBox(btnUpdate, btnDuplicate, btnSave, btnDelete);
            { //初始化區塊
                pane.setAlignment(Pos.CENTER);
                pane.setSpacing(10);
            }

            
            // Void 是 java.lang 套件裡的類別，代表「沒有型別」或「無值」
            // java.lang.* 會自動匯入，所以不用手動 import Void
            // 在 TableColumn<Product, Void> 中，Void 表示這個欄位不對應任何資料屬性，只用來放元件
            // 覆寫 TableCell 的 updateItem 方法，根據是否為空列決定是否顯示按鈕群組
            // 在 JavaFX 中，updateItem(Void item, boolean empty) 會在以下幾種情況自動被呼叫：
            // TableView 剛建立時（例如 new TableView<>() 或 initializeProductTable() 時）。
            // 設定資料來源時（例如 table.setItems(product_list);）。
            // 資料內容有變動時（例如 product_list.add(...)、product_list.remove(...)、product_list.set(...)）。
            // TableView 需要重繪時（例如視窗縮放、切換頁籤、或 TableView 重新整理）。
            // 這裡的 item 永遠都是 null，因為這個 TableColumn 的型別是 Void 放的是按鈕元件
            // 如果 TableColumn 型別是 String 或 Integer，item 會是對應 row 的資料屬性值。
            // 但你的 actionColumn 型別是 Void，所以 item 只會是 null。
            // 你只需要根據 empty 來決定 cell 要不要顯示內容，item 在這裡沒有實際用途。

            @Override // 告訴編譯器這是覆寫父類別的方法（TableCell 的 updateItem 方法）
            protected void updateItem(Void item, boolean empty) {
                // 呼叫父類別的 updateItem 方法，確保 TableCell 的基本行為正常
                super.updateItem(item, empty); // 呼叫父類別的 updateItem 方法，確保 TableCell 的基本行為正常

                //System.out.println("Action欄位的按鈕pane排版被重繪");
                //Integer item_index = getTableRow().getIndex();
                //System.out.println("row 編號:"+item_index + " 的 Action 欄位被重繪");
                
                //System.out.println("updateItem called, item: " + item); //
                //System.out.println("updateItem called, empty: " + empty);
                
                
                // 如果這一列不是空的（有資料）
                if (!empty) {
                    // 顯示自訂的按鈕群組（pane）在這個 cell 裡
                    this.setGraphic(pane); 
                } else {
                    // 如果是空列（沒有資料），就不顯示任何內容
                    this.setGraphic(null);
                }
            }
        }); //action column的定義

        //--------------------
        // 11. 將所有欄位加入TableView
        //--------------------
        table.getColumns().add(idColumn);
        table.getColumns().add(categoryColumn);
        table.getColumns().add(nameColumn);
        table.getColumns().add(priceColumn);
        table.getColumns().add(imageUrlColumn);
        table.getColumns().add(descriptionColumn);
        table.getColumns().add(actionColumn);

        table.setItems(product_list);

        return table;
    }
    //--------------------
    // End of class
    //--------------------
}
