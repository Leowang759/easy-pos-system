package mypos;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.TreeMap;

import db.OrderEntryDbManagerSimple;
import db.ProductDbManagerSimple;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.util.converter.IntegerStringConverter;
import models.OrderDetailEntry;
import models.Product;
import models.SaleOrder;

public class OrderPane extends VBox {

    // 使用 OrderEntryDbManagerSimple 來處理資料庫操作
    private OrderEntryDbManagerSimple orderEntryDbManager = new db.OrderEntryDbManagerSimple();

    private final ProductDbManagerSimple productDbManager = new ProductDbManagerSimple();
    // 讀取產品詳細資訊
    private final TreeMap<String, Product> product_dict = productDbManager.getProducts();

    // 用於儲存訂單項目的可觀察列表，當資料變更時自動更新UI
    private ObservableList<OrderDetailEntry> order_list;

    // 訂單表格控制項
    private TableView<OrderDetailEntry> table;

    // 顯示總金額的文字區域
    private final TextArea display = new TextArea();
    // 設置TextArea的高度或行數 
    // 大括弧的作用

    {
        display.setWrapText(true);  // 自動換行
        display.setEditable(false);  // 設置為不可編輯
        display.setPrefWidth(200);  // 設定寬度為200像素
        display.setPrefHeight(50);  // 指定精確高度為50像素
        display.setPrefRowCount(2);  // 或設置首選行數為2
    }

    // 建構子 - 初始化UI組件和事件處理
    public OrderPane() {
        this.setSpacing(10);
        this.setPadding(new Insets(10));

        // 載入Bootstrap CSS
        //this.getStylesheets().add(getClass().getResource("/css/bootstrap3.css").toExternalForm());
        // 初始化表格和控件
        initializeOrderTable();

        // 添加訂單操作按鈕
        this.getChildren().add(getOrderOperationContainer());

        // 添加表格和總金額顯示
        this.getChildren().add(table);
        this.getChildren().add(display);
    }

    private TilePane getOrderOperationContainer() {
        // Create buttons for order operations
        // Button btnAdd = new Button("新增一筆果汁");
        // btnAdd.setOnAction((ActionEvent event) -> {
        //     // 將ID為p-j-101的產品(奇異果汁)加入購物車
        //     addToCart("p-j-101");
        //     System.out.println("新增一筆(奇異果汁)");
        // });

        Button btnDelete = new Button("刪除一筆");
        //btnDelete.getStyleClass().add("btn-danger"); // 使用Bootstrap的danger樣式
        btnDelete.getStyleClass().setAll("button", "danger");

        btnDelete.setOnAction((ActionEvent event) -> {
            OrderDetailEntry selectedItem = table.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                // 從訂單列表中移除所選項目
                order_list.remove(selectedItem);
                // 重新計算總金額
                checkTotal();
                System.out.println("Deleted order: " + selectedItem.getProductName());
            }
        });

        Button btnCheckout = new Button("結帳");
        //btnCheckout.getStyleClass().add("btn-primary"); // 結帳按鈕用primary藍色樣式更合適
        btnCheckout.getStyleClass().setAll("button", "primary");
        btnCheckout.setOnAction((ActionEvent event) -> {
            if (!order_list.isEmpty()) {
                // 取得總金額
                double total = 0;
                for (OrderDetailEntry od : order_list) {
                    total += od.getProductPrice() * od.getQuantity();
                }

                // 將訂單資料存入資料庫
                boolean saveSuccess = saveOrderToDatabase(total, order_list);
                //boolean saveSuccess = true;

                // 清空購物車
                order_list.clear();
                // 更新顯示
                if (saveSuccess) {
                    display.setText("結帳完成！金額：" + Math.round(total) + "元\n訂單已儲存到資料庫");
                    System.out.println("結帳完成，總金額：" + Math.round(total) + "元，訂單已儲存到資料庫");
                } else {
                    display.setText("結帳完成！金額：" + Math.round(total) + "元\n但儲存到資料庫失敗");
                    System.out.println("結帳完成，總金額：" + Math.round(total) + "元，但儲存到資料庫失敗");
                }
            } else {
                display.setText("購物車是空的，無法結帳");
                System.out.println("購物車是空的，無法結帳");
            }
        });

        // Create container for buttons
        // 訂單操作按鈕容器
        TilePane operationBtnTile = new TilePane();
        operationBtnTile.setVgap(10);
        operationBtnTile.setHgap(10);

        //operationBtnTile.getChildren().add(btnAdd);
        operationBtnTile.getChildren().add(btnDelete);
        operationBtnTile.getChildren().add(btnCheckout);

        return operationBtnTile;
    }

    // 初始化訂單表格及相關控件
    private void initializeOrderTable() {
        // 初始化空的訂單列表
        order_list = FXCollections.observableArrayList();

        // 初始化表格並設置為可編輯
        table = new TableView<>();
        table.setEditable(true);
        table.setPrefHeight(300);

        // 定義品名欄位
        TableColumn<OrderDetailEntry, String> order_item_name = new TableColumn<>("品名");
        order_item_name.setCellValueFactory(new PropertyValueFactory<>("productName"));
        order_item_name.setPrefWidth(100);
        order_item_name.setMinWidth(100);

        // 定義價格欄位
        TableColumn<OrderDetailEntry, Integer> order_item_price = new TableColumn<>("價格");
        order_item_price.setCellValueFactory(new PropertyValueFactory<>("productPrice"));

        // 定義數量欄位(可編輯)
        TableColumn<OrderDetailEntry, Integer> order_item_qty = new TableColumn<>("數量");
        order_item_qty.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        // 設置數量欄位為可編輯，並處理字串到整數的轉換
        order_item_qty.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));

        // 定義數量欄位編輯完成後的處理邏輯
        order_item_qty.setOnEditCommit(event -> {
            int row_num = event.getTablePosition().getRow();  // 取得被修改的行號
            int new_val = event.getNewValue();  // 取得用戶輸入的新數量
            OrderDetailEntry target = event.getTableView().getItems().get(row_num);  // 取得對應的訂單項目
            target.setQuantity(new_val);  // 更新數量
            checkTotal();  // 重新計算總金額

            System.out.println("哪個產品被修改數量:" + order_list.get(row_num).getProductName());
            System.out.println("數量被修改為:" + order_list.get(row_num).getQuantity());
        });

        // 將訂單列表設為表格的數據來源
        table.setItems(order_list);

        // 將所有欄位加入表格
        table.getColumns().add(order_item_name);
        table.getColumns().add(order_item_price);
        table.getColumns().add(order_item_qty);

        // 設定表格列寬調整策略，避免出現空白列
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        //table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);
    }

    private void checkTotal() {
        double total = 0;
        for (OrderDetailEntry od : order_list) {
            total += od.getProductPrice() * od.getQuantity();
        }
        String totalmsg = String.format("%s %d\n", "總金額:", Math.round(total));
        display.setText(totalmsg);
    }

    // 實現OrderManager介面的addToCart方法
    public void addToCart(String item_id) {
        boolean duplication = false;

        // 檢查產品是否已經在購物車中
        for (int i = 0; i < order_list.size(); i++) {
            if (order_list.get(i).getProductId().equals(item_id)) {
                // 如果已存在，增加數量
                int qty = order_list.get(i).getQuantity() + 1;
                order_list.get(i).setQuantity(qty);
                duplication = true;
                table.refresh();  // 刷新表格顯示
                checkTotal();     // 重新計算總金額
                System.out.println(item_id + " 已經在購物車中，數量 +1");
                break;
            }
        }

        // 如果是新產品，則添加到購物車
        if (!duplication) {
            OrderDetailEntry new_ord = new OrderDetailEntry(
                    item_id,
                    product_dict.get(item_id).getName(),
                    product_dict.get(item_id).getPrice(),
                    1);  // 初始數量為1
            order_list.add(new_ord);  // 添加到訂單列表
            System.out.println("已添加新項目到購物車: " + item_id);
            checkTotal();  // 更新總金額
        }
    }

    // 將訂單資料存入資料庫
    private boolean saveOrderToDatabase(double totalAmount, ObservableList<OrderDetailEntry> orderDetails) {
        try {

            // 創建訂單編號 (例如: ord-yyyyMMdd-HHmmss)
            LocalDateTime now = LocalDateTime.now();
            String orderId = "ord-" + now.format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));

            // 創建 SaleOrder 物件
            SaleOrder saleOrder = new SaleOrder();
            saleOrder.setOrderId(orderId);
            saleOrder.setOrderDate(now); // 使用當前時間作為訂單日期
            //saleOrder.setOrderDate(java.sql.Timestamp.valueOf(now));
            saleOrder.setTotalAmount(totalAmount);
            saleOrder.setCustomerId("customer-101"); // 假設使用預設客戶

            /* 
             * 方法一: 將訂單明細全部加入 SaleOrder 物件，再一次性儲存
             * 優點: 可以在一個交易中完成所有插入，保證資料一致性
             * 缺點: 需要建立完整的物件關聯，增加記憶體使用
             */
 /*
             * 方法二: 先儲存訂單主檔，再逐一儲存訂單明細
             * 優點: 程式碼更簡潔，直接使用資料庫管理類別的方法
             * 缺點: 如果中途發生錯誤，可能導致資料不一致（除非數據庫管理類別內部有事務處理）
             */
            // 保存訂單主檔
            boolean success = orderEntryDbManager.insertSaleOrder(saleOrder);

            // 如果訂單主檔保存成功，繼續保存訂單明細
            if (success) {
                for (OrderDetailEntry item : orderDetails) {
                    // 創建符合資料庫結構的 OrderDetail 物件並直接保存
                    models.OrderDetail detail = new models.OrderDetail();
                    detail.setOrderId(orderId);
                    detail.setProductId(item.getProductId());
                    detail.setQuantity(item.getQuantity());

                    // 個別儲存每筆訂單明細
                    boolean detailSuccess = orderEntryDbManager.insertOrderDetail(detail);
                    if (!detailSuccess) {
                        System.err.println("儲存訂單明細失敗: " + item.getProductId());
                        // 考慮是否要在明細儲存失敗時設置整體操作為失敗
                        // success = false;
                    }
                }
            }

            if (success) {
                System.out.println("訂單 " + orderId + " 已成功儲存到資料庫");
            } else {
                System.err.println("儲存訂單到資料庫時發生錯誤");
            }

            return success;
        } catch (Exception e) {
            System.err.println("儲存訂單過程中發生錯誤: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}
